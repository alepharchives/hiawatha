//
//  HiawathaWebserverPref.m
//  HiawathaWebserver
//
//  Created by Hugo Leisink on 6/9/08.
//  Copyright (c) 2008 Hugo Leisink. All rights reserved.
//

#import "HiawathaWebserverPref.h"


@implementation HiawathaWebserverPref

- (void) mainViewDidLoad
{
}

@end
